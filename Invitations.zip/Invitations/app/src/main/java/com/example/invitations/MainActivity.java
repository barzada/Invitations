package com.example.invitations;

import android.os.AsyncTask;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import android.provider.CalendarContract;
import android.database.Cursor;


public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    private static final String CALENDAR_URL = "https://example.com/calendar.json";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        new GetCalendarDataTask().execute(CALENDAR_URL);
    }

    private class GetCalendarDataTask extends AsyncTask<String, Void, JSONObject> {

        @Override
        protected JSONObject doInBackground(String... urls) {
            JSONObject result = null;

            try {
                URL url = new URL(urls[0]);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();

                BufferedReader reader = new BufferedReader(
                        new InputStreamReader(urlConnection.getInputStream()));

                StringBuilder response = new StringBuilder();
                String line;

                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }

                result = new JSONObject(response.toString());
            } catch (Exception e) {
                Log.e(TAG, "Error retrieving calendar data", e);
            }

            return result;
        }

        @Override
        protected void onPostExecute(JSONObject calendarData) {
            if (calendarData == null) {
                Toast.makeText(MainActivity.this, "Error retrieving calendar data", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                // Parse the event data from the JSON object
                String eventName = calendarData.getString("name");
                String eventLocation = calendarData.getString("location");
                String startDate = calendarData.getString("start_date");
                String endDate = calendarData.getString("end_date");

                // Add the event to the calendar
                addEventToCalendar(eventName, eventLocation, startDate, endDate);
            } catch (JSONException e) {
                Log.e(TAG, "Error parsing calendar data", e);
                Toast.makeText(MainActivity.this, "Error parsing calendar data", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void addEventToCalendar(String eventName, String eventLocation, String startDate, String endDate) {
        // Get the calendar ID for the user's default calendar
        String[] projection = new String[]{CalendarContract.Calendars._ID};
        Cursor cursor = getContentResolver().query(CalendarContract.Calendars.CONTENT_URI, projection,
                CalendarContract.Calendars.ACCOUNT_NAME + " = ? AND " + CalendarContract.Calendars.ACCOUNT_TYPE + " = ?",
                new String[]{CalendarContract.ACCOUNT_NAME_LOCAL, CalendarContract.ACCOUNT_TYPE_LOCAL}, null);

        if (cursor == null || cursor.getCount() == 0) {
            Log.e(TAG, "No local calendar found");
            Toast.makeText(MainActivity.this, "No local calendar found", Toast.LENGTH_SHORT).show();
            return;
        }

        cursor.moveToFirst();
        long calendarId = cursor.getLong(0);

        // Create a new event in the calendar
        ContentValues values = new ContentValues();
        values.put(CalendarContract.Events.TITLE, eventName);

    }